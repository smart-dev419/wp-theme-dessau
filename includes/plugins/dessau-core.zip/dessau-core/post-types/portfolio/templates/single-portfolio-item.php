<?php

get_header();

dessau_select_get_title();

do_action('dessau_select_before_main_content');

dessau_core_get_single_portfolio();

get_footer();