<?php if(!empty(the_content())) {?>
    <div class="qodef-ps-info-item qodef-ps-content-item">
        <?php the_content(); ?>
    </div>
<?php }?>