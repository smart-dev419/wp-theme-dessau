<?php $title   = get_the_title(); ?>

<h3 class="qodef-ps-title"><?php echo esc_html( $title ); ?></h3>