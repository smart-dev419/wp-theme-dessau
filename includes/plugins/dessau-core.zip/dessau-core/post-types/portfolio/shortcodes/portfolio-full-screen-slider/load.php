<?php

require_once 'portfolio-full-screen-slider.php';
require_once 'helper-functions.php';