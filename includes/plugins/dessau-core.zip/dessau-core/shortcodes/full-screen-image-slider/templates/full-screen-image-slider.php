<div class="qodef-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
	<div class="qodef-fsis-slider qodef-owl-slider" <?php echo dessau_select_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="qodef-fsis-thumb-nav qodef-fsis-prev-nav"></div>
	<div class="qodef-fsis-thumb-nav qodef-fsis-next-nav"></div>
	<div class="qodef-fsis-slider-mask"></div>
</div>