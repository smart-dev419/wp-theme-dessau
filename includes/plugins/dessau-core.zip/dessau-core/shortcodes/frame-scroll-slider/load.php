<?php

include_once DESSAU_CORE_SHORTCODES_PATH . '/frame-scroll-slider/functions.php';
include_once DESSAU_CORE_SHORTCODES_PATH . '/frame-scroll-slider/frame-scroll-slider.php';