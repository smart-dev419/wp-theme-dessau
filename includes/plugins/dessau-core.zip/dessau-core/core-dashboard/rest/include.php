<?php

require_once DESSAU_CORE_ABS_PATH . '/core-dashboard/rest/rest.php';